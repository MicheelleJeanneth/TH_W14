﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH_Micheelle_01
{
    public partial class Form1 : Form
    {
        MySqlDataAdapter sqldataadapter;
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;

        string query;

        bool del = false;

        DataTable match = new DataTable();

        DataTable teamhome = new DataTable();
        DataTable teamaway = new DataTable();

        DataTable matchid = new DataTable();

        DataTable dtplayer = new DataTable();

        DataTable matchdate = new DataTable();

        DataTable tim = new DataTable();

        DataTable id = new DataTable();

        DataTable date = new DataTable();

        DataTable insertdmatch = new DataTable();
        DataTable insertmatch = new DataTable();


        public void tanggal()
        {
            bool date = true;
            if (datetimepicker_match.Value.Year == dateTimePicker2.Value.Year)
            {
                if (datetimepicker_match.Value.Month == dateTimePicker2.Value.Month)
                {
                    if (datetimepicker_match.Value.Day < dateTimePicker2.Value.Day)
                    {
                        date = false;
                        MessageBox.Show("Tanggal hrs lebih besar");
                    }
                }
                else if (datetimepicker_match.Value.Month < dateTimePicker2.Value.Month)
                {
                    date = false;
                    MessageBox.Show("Bulan harus lebih besar");
                }
            }
            else if (datetimepicker_match.Value.Year < dateTimePicker2.Value.Year)
            {
                date = false;
                MessageBox.Show("Tahun harus lebih besar");
            }

            //-------------------
            if (date == true)
            {
                int year = datetimepicker_match.Value.Year;
                string id = year.ToString();
                query = $"SELECT count(*) FROM `match` WHERE SUBSTRING(match_id,1,4) = '{id}'";
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(matchid);

                if (Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0].ToString()) < 9)
                {
                    id = year.ToString() + "00" + (Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0]) + 1).ToString();


                }
                else if (Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0].ToString()) < 100)
                {
                    id = year.ToString() + "0" + (Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0]) + 1).ToString();

                }
                else
                {
                    id = year.ToString() + (Convert.ToInt32(matchid.Rows[matchid.Rows.Count - 1][0]) + 1).ToString();

                }
                txbx_matchid.Text = id;
            }
            else
            {
                txbx_matchid.Text = "";
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            match.Columns.Add("Minute");
            match.Columns.Add("Team");
            match.Columns.Add("Player");
            match.Columns.Add("Type");
            dgv.DataSource = match;

            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=#MichstuDY23inUCISB-es05!;database=premier_league");
            string sql = "SELECT team_name, team_id FROM team";
            sqlcommand = new MySqlCommand(sql, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            
            sqldataadapter.Fill(teamhome);
            cobox_teamhome.DataSource = teamhome;
            cobox_teamhome.DisplayMember = "team_name";
            cobox_teamhome.ValueMember = "team_id";
            cobox_teamhome.Text = "";

            sqldataadapter.Fill(teamaway);
            cobox_teamaway.DataSource = teamaway;
            cobox_teamaway.DisplayMember = "team_name";
            cobox_teamaway.ValueMember = "team_id";
            cobox_teamaway.Text = "";

            //-----------------------cek tanggal--------------------------------
            query = "SELECT match_date from `match`";
            sqlcommand = new MySqlCommand(query, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(date);
            dateTimePicker2.Text = date.Rows[date.Rows.Count - 1][0].ToString();

            //------------------------ insert database ------------------------
            insertdmatch.Columns.Add("Match_id");
            insertdmatch.Columns.Add("Minute");
            insertdmatch.Columns.Add("Team_id");
            insertdmatch.Columns.Add("Player_id");
            insertdmatch.Columns.Add("Type");
            dgv_insertdmatch.DataSource = insertdmatch;

            insertmatch.Columns.Add("match_id");
            insertmatch.Columns.Add("match_date");
            insertmatch.Columns.Add("team_home");
            insertmatch.Columns.Add("team_away");
            insertmatch.Columns.Add("goal_home");
            insertmatch.Columns.Add("goal_away");
            insertmatch.Columns.Add("referee_id");

            tim.Columns.Add("team_name");
            tim.Columns.Add("team_id");

            tanggal();
        }

        private void cobox_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobox_teamhome.Text == cobox_teamaway.Text)
            {
                MessageBox.Show("Team shouldn't be same");
                tim.Rows.Clear();
                cobox_team.DataSource = tim;
                cobox_team.DisplayMember = "team_name";
                cobox_player.Text = "";
            }
            else if (cobox_teamaway.Text != "" && cobox_teamhome.Text != "")
            {
                tim.Rows.Clear();
                tim.Rows.Add(cobox_teamaway.Text, cobox_teamaway.SelectedValue);
                tim.Rows.Add(cobox_teamhome.Text, cobox_teamhome.SelectedValue);
                cobox_team.DataSource = tim;
                cobox_team.DisplayMember = "team_name";
                cobox_team.ValueMember = "team_id";
                cobox_player.Text = "";
                cobox_team.Text = "";
            }
        }

        private void cobox_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobox_teamhome.Text == cobox_teamaway.Text)
            {
                MessageBox.Show("Team shouldn't be same");
                tim.Rows.Clear();
                cobox_team.DataSource = tim;
                cobox_team.DisplayMember = "team_name";
                cobox_player.Text = "";
            }
            else if (cobox_teamaway.Text != "" && cobox_teamhome.Text != "")
            {
                tim.Rows.Clear();
                tim.Rows.Add(cobox_teamaway.Text, cobox_teamaway.SelectedValue);
                tim.Rows.Add(cobox_teamhome.Text, cobox_teamhome.SelectedValue);
                cobox_team.DataSource = tim;
                cobox_team.DisplayMember = "team_name";
                cobox_team.ValueMember = "team_id";
                cobox_player.Text = "";
                cobox_team.Text = "";
            }
        }

        private void datetimepicker_match_ValueChanged(object sender, EventArgs e)
        {
            tanggal();
        }

        private void cobox_team_SelectedIndexChanged(object sender, EventArgs e)
        {

            string value = "";
            if (cobox_teamhome.Text == cobox_team.Text)
            {
                value = cobox_teamhome.SelectedValue.ToString();
            }
            else if (cobox_teamaway.Text == cobox_team.Text)
            {
                value = cobox_teamaway.SelectedValue.ToString();
            }
            query = $"SELECT player_name, player_id FROM player p, team t where'{value}' = p.team_id group by 1,2";
            sqlcommand = new MySqlCommand(query, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            DataTable dtplayer = new DataTable();
            sqldataadapter.Fill(dtplayer);
            cobox_player.DataSource = dtplayer;
            cobox_player.DisplayMember = "player_name";
            cobox_player.ValueMember = "player_id";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            cobox_teamaway.Enabled = false;
            cobox_teamhome.Enabled = false;
            datetimepicker_match.Enabled = false;
            match.Rows.Add(txbx_minute.Text, cobox_team.Text, cobox_player.Text, cobox_type.Text);
            insertdmatch.Rows.Add(txbx_matchid.Text, txbx_minute.Text, cobox_team.SelectedValue, cobox_player.SelectedValue, cobox_type.Text);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            
            if (del == true)
            {
                int index = dgv.CurrentRow.Index;
                match.Rows.RemoveAt(index);
                insertdmatch.Rows.RemoveAt(index);
                del = false;
                dgv.ClearSelection();
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            int goalhome = 0;
            int goalaway = 0;
            string date = "";
            if (datetimepicker_match.Value.Month < 10 && datetimepicker_match.Value.Day < 10)
            {
                date = datetimepicker_match.Value.Year.ToString() + "-0" + datetimepicker_match.Value.Month.ToString() + "-0" + datetimepicker_match.Value.Day.ToString();
            }
            else if (datetimepicker_match.Value.Month >= 10 && datetimepicker_match.Value.Day >= 10)
            {
                date = datetimepicker_match.Value.Year.ToString() + "-" + datetimepicker_match.Value.Month.ToString() + "-" + datetimepicker_match.Value.Day.ToString();
            }
            else if (datetimepicker_match.Value.Month < 10 && datetimepicker_match.Value.Day >= 10)
            {
                date = datetimepicker_match.Value.Year.ToString() + "-0" + datetimepicker_match.Value.Month.ToString() + "-" + datetimepicker_match.Value.Day.ToString();
            }
            else if (datetimepicker_match.Value.Month >= 10 && datetimepicker_match.Value.Day < 10)
            {
                date = datetimepicker_match.Value.Year.ToString() + "-" + datetimepicker_match.Value.Month.ToString() + "-0" + datetimepicker_match.Value.Day.ToString();
            }

            for (int i = 0; i < match.Rows.Count; i++)
            {
                if (match.Rows[i][1].ToString() == cobox_teamhome.Text)
                {
                    if (match.Rows[i][3].ToString() == "GW")
                    {
                        goalaway++;
                    }
                    else if (match.Rows[i][3].ToString() == "GO" || match.Rows[i][3].ToString() == "GP")
                    {
                        goalhome++;
                    }
                }
                else if (match.Rows[i][1].ToString() == cobox_teamaway.Text)
                {
                    if (match.Rows[i][3].ToString() == "GW")
                    {
                        goalhome++;
                    }
                    else if (match.Rows[i][3].ToString() == "GO" || match.Rows[i][3].ToString() == "GP")
                    {
                        goalaway++;
                    }
                }
            }
            
            for (int i = 0; i < insertdmatch.Rows.Count; i++)
            {
                query = $"INSERT INTO dmatch VALUES ('{insertdmatch.Rows[i][0].ToString()}','{insertdmatch.Rows[i][1].ToString()}','{insertdmatch.Rows[i][2].ToString()}','{insertdmatch.Rows[i][3].ToString()}','{insertdmatch.Rows[i][4].ToString()}','0')";
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
            }
            query = $"INSERT INTO `match` VALUES ('{txbx_matchid.Text}','{date}','{cobox_teamhome.SelectedValue}','{cobox_teamaway.SelectedValue}','{goalhome.ToString()}','{goalaway.ToString()}','M002','0')";
            sqlconnect.Open();
            sqlcommand = new MySqlCommand(query, sqlconnect);
            sqlcommand.ExecuteNonQuery();
            sqlconnect.Close();

            match.Rows.Clear();
            insertdmatch.Rows.Clear();
            tanggal();
            cobox_teamhome.Enabled = true;
            cobox_teamaway.Enabled = true;
            datetimepicker_match.Enabled = true;
        }

        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            del = true;
        }

        private void txbx_matchid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
