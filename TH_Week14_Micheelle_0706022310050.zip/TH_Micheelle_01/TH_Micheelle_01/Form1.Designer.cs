﻿namespace TH_Micheelle_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txbx_matchid = new System.Windows.Forms.TextBox();
            this.cobox_teamhome = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cobox_teamaway = new System.Windows.Forms.ComboBox();
            this.datetimepicker_match = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.txbx_minute = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cobox_team = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cobox_player = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cobox_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dgv_insertdmatch = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_insertdmatch)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Match ID";
            // 
            // txbx_matchid
            // 
            this.txbx_matchid.Enabled = false;
            this.txbx_matchid.Location = new System.Drawing.Point(148, 20);
            this.txbx_matchid.Name = "txbx_matchid";
            this.txbx_matchid.Size = new System.Drawing.Size(280, 26);
            this.txbx_matchid.TabIndex = 1;
            this.txbx_matchid.TextChanged += new System.EventHandler(this.txbx_matchid_TextChanged);
            // 
            // cobox_teamhome
            // 
            this.cobox_teamhome.FormattingEnabled = true;
            this.cobox_teamhome.Location = new System.Drawing.Point(151, 122);
            this.cobox_teamhome.Name = "cobox_teamhome";
            this.cobox_teamhome.Size = new System.Drawing.Size(280, 28);
            this.cobox_teamhome.TabIndex = 2;
            this.cobox_teamhome.SelectedIndexChanged += new System.EventHandler(this.cobox_teamhome_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Team Home";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(475, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Team Away";
            // 
            // cobox_teamaway
            // 
            this.cobox_teamaway.FormattingEnabled = true;
            this.cobox_teamaway.Location = new System.Drawing.Point(595, 122);
            this.cobox_teamaway.Name = "cobox_teamaway";
            this.cobox_teamaway.Size = new System.Drawing.Size(280, 28);
            this.cobox_teamaway.TabIndex = 4;
            this.cobox_teamaway.SelectedIndexChanged += new System.EventHandler(this.cobox_teamaway_SelectedIndexChanged);
            // 
            // datetimepicker_match
            // 
            this.datetimepicker_match.Location = new System.Drawing.Point(592, 20);
            this.datetimepicker_match.Name = "datetimepicker_match";
            this.datetimepicker_match.Size = new System.Drawing.Size(280, 26);
            this.datetimepicker_match.TabIndex = 6;
            this.datetimepicker_match.ValueChanged += new System.EventHandler(this.datetimepicker_match_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(472, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Match Date";
            // 
            // dgv
            // 
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(35, 174);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 62;
            this.dgv.RowTemplate.Height = 28;
            this.dgv.Size = new System.Drawing.Size(692, 287);
            this.dgv.TabIndex = 8;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // txbx_minute
            // 
            this.txbx_minute.Location = new System.Drawing.Point(859, 174);
            this.txbx_minute.Name = "txbx_minute";
            this.txbx_minute.Size = new System.Drawing.Size(190, 26);
            this.txbx_minute.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(739, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Minute";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(739, 219);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Team";
            // 
            // cobox_team
            // 
            this.cobox_team.FormattingEnabled = true;
            this.cobox_team.Location = new System.Drawing.Point(859, 216);
            this.cobox_team.Name = "cobox_team";
            this.cobox_team.Size = new System.Drawing.Size(190, 28);
            this.cobox_team.TabIndex = 11;
            this.cobox_team.SelectedIndexChanged += new System.EventHandler(this.cobox_team_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(739, 263);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 20);
            this.label7.TabIndex = 14;
            this.label7.Text = "Player";
            // 
            // cobox_player
            // 
            this.cobox_player.FormattingEnabled = true;
            this.cobox_player.Location = new System.Drawing.Point(859, 260);
            this.cobox_player.Name = "cobox_player";
            this.cobox_player.Size = new System.Drawing.Size(190, 28);
            this.cobox_player.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(739, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 16;
            this.label8.Text = "Type";
            // 
            // cobox_type
            // 
            this.cobox_type.FormattingEnabled = true;
            this.cobox_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GW",
            "CR",
            "CY",
            "PM"});
            this.cobox_type.Location = new System.Drawing.Point(859, 306);
            this.cobox_type.Name = "cobox_type";
            this.cobox_type.Size = new System.Drawing.Size(190, 28);
            this.cobox_type.TabIndex = 15;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(859, 351);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(92, 33);
            this.btn_add.TabIndex = 17;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(957, 351);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(92, 33);
            this.btn_delete.TabIndex = 18;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(635, 479);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(92, 33);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(592, 71);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(280, 26);
            this.dateTimePicker2.TabIndex = 22;
            this.dateTimePicker2.Visible = false;
            // 
            // dgv_insertdmatch
            // 
            this.dgv_insertdmatch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_insertdmatch.Location = new System.Drawing.Point(35, 260);
            this.dgv_insertdmatch.Name = "dgv_insertdmatch";
            this.dgv_insertdmatch.RowHeadersWidth = 62;
            this.dgv_insertdmatch.RowTemplate.Height = 28;
            this.dgv_insertdmatch.Size = new System.Drawing.Size(692, 195);
            this.dgv_insertdmatch.TabIndex = 23;
            this.dgv_insertdmatch.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 618);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.dgv_insertdmatch);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cobox_type);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cobox_player);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cobox_team);
            this.Controls.Add(this.txbx_minute);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.datetimepicker_match);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cobox_teamaway);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cobox_teamhome);
            this.Controls.Add(this.txbx_matchid);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_insertdmatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txbx_matchid;
        private System.Windows.Forms.ComboBox cobox_teamhome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cobox_teamaway;
        private System.Windows.Forms.DateTimePicker datetimepicker_match;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox txbx_minute;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cobox_team;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cobox_player;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cobox_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridView dgv_insertdmatch;
    }
}

